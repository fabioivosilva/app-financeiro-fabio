// Configurações — Pessoas, Cartões, Categorias, Sistema, Zona de Perigo
const { useState: useStateC, useMemo: useMemoC, useRef: useRefC } = React;

const CARTOES = [
  { id: "c1", final: "4291", bandeira: "VISA", nome: "Itaú Visa Infinite",   pessoa: "fabio"  },
  { id: "c2", final: "8120", bandeira: "MASTER", nome: "Itaú Mastercard Black", pessoa: "thiago" },
  { id: "c3", final: "5572", bandeira: "VISA", nome: "Itaú Click",            pessoa: "fabio"  },
];

// Expandir CATEGORIAS com grupos + limite + meta + excluir totais + subcategorias
const CATEGORIAS_FULL = [
  // Fixas
  { id: "casa",        grupo: "fixas",     limite: 3200, metaId: null,  excluirTotais: false,
    subs: [
      { id: "casa-aluguel",   nome: "Aluguel",         icon: "home_work",    keywords: 3,  count: 1 },
      { id: "casa-condominio",nome: "Condomínio",      icon: "apartment",    keywords: 2,  count: 1 },
      { id: "casa-luz",       nome: "Luz",             icon: "bolt",         keywords: 2,  count: 1 },
      { id: "casa-internet",  nome: "Internet/TV",     icon: "wifi",         keywords: 2,  count: 1 },
    ]
  },
  { id: "saude",       grupo: "fixas",     limite:  900, metaId: null,  excluirTotais: false,
    subs: [
      { id: "saude-plano",    nome: "Plano de saúde",  icon: "medical_services", keywords: 2, count: 1 },
      { id: "saude-farmacia", nome: "Farmácia",        icon: "medication",   keywords: 5,  count: 4 },
      { id: "saude-academia", nome: "Academia",        icon: "fitness_center", keywords: 1, count: 1 },
    ]
  },
  { id: "educacao",    grupo: "fixas",     limite:  400, metaId: null,  excluirTotais: false,
    subs: [
      { id: "edu-cursos",     nome: "Cursos online",   icon: "school",       keywords: 4,  count: 2 },
    ]
  },
  { id: "assinatura",  grupo: "fixas",     limite:  150, metaId: null,  excluirTotais: false,
    subs: [
      { id: "ass-streaming",  nome: "Streaming",       icon: "movie",        keywords: 4,  count: 3 },
      { id: "ass-musica",     nome: "Música",          icon: "music_note",   keywords: 1,  count: 1 },
      { id: "ass-software",   nome: "Software",        icon: "code",         keywords: 3,  count: 2 },
    ]
  },
  // Variáveis
  { id: "mercado",     grupo: "variaveis", limite: 1200, metaId: null,  excluirTotais: false,
    subs: [
      { id: "merc-super",     nome: "Supermercado",    icon: "shopping_cart", keywords: 6, count: 8 },
      { id: "merc-feira",     nome: "Feira/Hortifruti", icon: "eco",         keywords: 2,  count: 3 },
      { id: "merc-padaria",   nome: "Padaria",         icon: "bakery_dining",keywords: 1,  count: 4 },
    ]
  },
  { id: "restaurante", grupo: "variaveis", limite:  600, metaId: null,  excluirTotais: false,
    subs: [
      { id: "rest-delivery",  nome: "Delivery",        icon: "delivery_dining",keywords: 4, count: 12 },
      { id: "rest-restaurante",nome: "Restaurante",    icon: "restaurant",   keywords: 3,  count: 6 },
      { id: "rest-cafe",      nome: "Café/Lanche",     icon: "local_cafe",   keywords: 3,  count: 9 },
    ]
  },
  { id: "transporte",  grupo: "variaveis", limite:  500, metaId: null,  excluirTotais: false,
    subs: [
      { id: "trans-app",      nome: "Apps (Uber/99)",  icon: "local_taxi",   keywords: 2,  count: 23 },
      { id: "trans-combustivel",nome: "Combustível",   icon: "local_gas_station",keywords: 4,count: 5 },
      { id: "trans-estacion", nome: "Estacionamento",  icon: "local_parking",keywords: 3,  count: 8 },
    ]
  },
  { id: "lazer",       grupo: "variaveis", limite:  400, metaId: "m2",  excluirTotais: false,
    subs: [
      { id: "lazer-cinema",   nome: "Cinema/Teatro",   icon: "theaters",     keywords: 3,  count: 2 },
      { id: "lazer-viagem",   nome: "Viagem",          icon: "flight",       keywords: 5,  count: 1 },
      { id: "lazer-hobby",    nome: "Hobbies",         icon: "palette",      keywords: 2,  count: 3 },
    ]
  },
  { id: "outros",      grupo: "variaveis", limite: null, metaId: null,  excluirTotais: false,
    subs: []
  },
  // Receitas
  { id: "salario",     grupo: "receitas",  limite: null, metaId: null,  excluirTotais: false,
    subs: [
      { id: "sal-clt",        nome: "CLT",             icon: "badge",        keywords: 1,  count: 1 },
      { id: "sal-13",         nome: "13º/Bônus",       icon: "redeem",       keywords: 2,  count: 0 },
    ]
  },
  { id: "freelance",   grupo: "receitas",  limite: null, metaId: "m1",  excluirTotais: false,
    subs: [
      { id: "free-projeto",   nome: "Projetos",        icon: "engineering",  keywords: 3,  count: 2 },
    ]
  },
  // Internas
  { id: "transferencia", grupo: "internas", limite: null, metaId: null, excluirTotais: true,
    subs: [
      { id: "tr-conta",       nome: "Entre contas",    icon: "swap_horiz",   keywords: 2,  count: 4 },
      { id: "tr-cofrinho",    nome: "Cofrinho",        icon: "savings",      keywords: 1,  count: 6 },
    ]
  },
];

const GRUPOS = [
  { id: "fixas",     label: "Fixas",                  icon: "lock",          color: "#6366F1" },
  { id: "variaveis", label: "Variáveis",              icon: "trending_up",   color: "#EC4899" },
  { id: "receitas",  label: "Receitas",               icon: "payments",      color: "#22C55E" },
  { id: "internas",  label: "Movimentações internas", icon: "swap_horiz",    color: "#94A3B8" },
];

function Config() {
  const [secao, setSecao] = useStateC("pessoas");
  const refs = {
    pessoas: useRefC(null),
    cartoes: useRefC(null),
    categorias: useRefC(null),
    sistema: useRefC(null),
    perigo: useRefC(null),
  };

  const goTo = (s) => {
    setSecao(s);
    refs[s].current?.scrollIntoView?.({ behavior: "auto", block: "start" });
  };

  return (
    <div className="page page-config">
      <PageHeader
        title="Configurações"
        subtitle="Pessoas, cartões, categorias e ajustes do sistema"
      />

      <div className="cfg-layout">
        {/* Side nav */}
        <aside className="cfg-side">
          {[
            { id: "pessoas",    label: "Pessoas & Cartões", icon: "group" },
            { id: "categorias", label: "Categorias",        icon: "label" },
            { id: "sistema",    label: "Sistema",           icon: "tune" },
            { id: "perigo",     label: "Zona de Perigo",    icon: "warning", danger: true },
          ].map(it => (
            <button
              key={it.id}
              className={"cfg-side-item " + (secao === it.id ? "cfg-side-item-on " : "") + (it.danger ? "cfg-side-item-danger" : "")}
              onClick={() => goTo(it.id)}
            >
              <Icon name={it.icon} size={18} />
              <span>{it.label}</span>
            </button>
          ))}
        </aside>

        {/* Content */}
        <div className="cfg-content">
          <section ref={refs.pessoas}>
            <PessoasCartoes />
          </section>
          <section ref={refs.categorias}>
            <CategoriasSection />
          </section>
          <section ref={refs.sistema}>
            <SistemaSection />
          </section>
          <section ref={refs.perigo}>
            <ZonaPerigoSection />
          </section>
        </div>
      </div>
    </div>
  );
}

// ============ Pessoas + Cartões ============
function PessoasCartoes() {
  return (
    <>
      <div className="cfg-section-head">
        <div>
          <div className="cfg-section-title">Pessoas & Cartões</div>
          <div className="t-xs t-muted">Vincule transações a pessoas e cartões aos seus titulares</div>
        </div>
      </div>

      <div className="grid-2">
        {/* Pessoas */}
        <Glass>
          <SectionHeader
            title="Pessoas"
            hint={`${PESSOAS.length} cadastradas`}
            right={<button className="btn-primary"><Icon name="person_add" size={14} /> Adicionar</button>}
          />
          <div className="pessoa-grid">
            {PESSOAS.map(p => (
              <div key={p.id} className="pessoa-card">
                <div
                  className="pessoa-card-avatar"
                  style={{ background: `linear-gradient(135deg, ${p.cor}, ${p.cor}80)` }}
                >
                  {p.iniciais}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div className="t-sm">{p.nome}</div>
                  <div className="t-xs t-muted">
                    {CARTOES.filter(c => c.pessoa === p.id).length} cartões vinculados
                  </div>
                </div>
                <div className="pessoa-actions">
                  <button className="btn-icon"><Icon name="edit" size={16} /></button>
                  <button className="btn-icon"><Icon name="delete" size={16} /></button>
                </div>
              </div>
            ))}
          </div>
        </Glass>

        {/* Cartões */}
        <Glass>
          <SectionHeader
            title="Cartões"
            hint={`${CARTOES.length} detectados`}
            right={<span className="t-xs t-muted"><Icon name="auto_awesome" size={12} /> Detectados ao importar</span>}
          />
          <div className="cartao-mini-grid">
            {CARTOES.map(c => {
              const p = PESSOAS.find(x => x.id === c.pessoa);
              return (
                <div key={c.id} className="cartao-mini">
                  <div className="cartao-mini-bandeira">{c.bandeira}</div>
                  <div className="cartao-mini-num">•••• {c.final}</div>
                  <div className="cartao-mini-foot">
                    <div className="cartao-mini-nome">{c.nome}</div>
                    <div className="cartao-mini-pessoa">
                      <div className="pessoa-avatar" style={{ background: p.cor + "30", color: p.cor, border: `1px solid ${p.cor}50`, width: 18, height: 18, fontSize: 10 }}>
                        {p.iniciais}
                      </div>
                      <span className="t-xs">{p.nome}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </Glass>
      </div>
    </>
  );
}

// ============ Categorias ============
function CategoriasSection() {
  const [busca, setBusca] = useStateC("");
  const [grupo, setGrupo] = useStateC("todos");

  const filtered = useMemoC(() => {
    return CATEGORIAS_FULL.filter(c => {
      const meta = CATEGORIAS[c.id];
      if (grupo !== "todos" && c.grupo !== grupo) return false;
      if (busca && !meta.label.toLowerCase().includes(busca.toLowerCase())) return false;
      return true;
    });
  }, [busca, grupo]);

  const grouped = useMemoC(() => {
    const out = {};
    filtered.forEach(c => { (out[c.grupo] = out[c.grupo] || []).push(c); });
    return out;
  }, [filtered]);

  return (
    <>
      <div className="cfg-section-head">
        <div>
          <div className="cfg-section-title">Categorias</div>
          <div className="t-xs t-muted">{CATEGORIAS_FULL.length} categorias em 4 grupos</div>
        </div>
        <button className="btn-primary"><Icon name="add" size={14} /> Nova categoria</button>
      </div>

      <Glass padded={false} className="cfg-cat-toolbar">
        <div className="search-wrap">
          <Icon name="search" size={18} className="t-muted" />
          <input placeholder="Buscar categoria..." value={busca} onChange={e => setBusca(e.target.value)} />
        </div>
        <div className="cfg-grupo-tabs">
          <button className={"cfg-grupo " + (grupo === "todos" ? "cfg-grupo-on" : "")} onClick={() => setGrupo("todos")}>
            Todas <span className="tab-count">{CATEGORIAS_FULL.length}</span>
          </button>
          {GRUPOS.map(g => {
            const count = CATEGORIAS_FULL.filter(c => c.grupo === g.id).length;
            return (
              <button
                key={g.id}
                className={"cfg-grupo " + (grupo === g.id ? "cfg-grupo-on" : "")}
                onClick={() => setGrupo(g.id)}
                style={grupo === g.id ? { borderColor: g.color, background: g.color + "20" } : {}}
              >
                <Icon name={g.icon} size={14} style={{ color: g.color }} />
                {g.label}
                <span className="tab-count">{count}</span>
              </button>
            );
          })}
        </div>
      </Glass>

      {GRUPOS.filter(g => grouped[g.id]?.length).map(g => (
        <div key={g.id} className="cfg-cat-group">
          <div className="cfg-cat-group-head">
            <div className="cfg-cat-group-icon" style={{ background: g.color + "20", color: g.color }}>
              <Icon name={g.icon} size={16} />
            </div>
            <div className="cfg-cat-group-title">{g.label}</div>
            <div className="t-xs t-muted">{grouped[g.id].length} categorias</div>
          </div>
          <div className="cfg-cat-grid">
            {grouped[g.id].map(c => {
              const meta = CATEGORIAS[c.id];
              const metaObj = c.metaId ? METAS.find(m => m.id === c.metaId) : null;
              return (
                <CategoryCard key={c.id} c={c} meta={meta} metaObj={metaObj} />
              );
            })}
          </div>
        </div>
      ))}

      {filtered.length === 0 && (
        <Glass>
          <div className="empty-state-mini">
            <Icon name="search_off" size={32} className="t-muted" />
            <div className="t-sm">Nenhuma categoria encontrada</div>
          </div>
        </Glass>
      )}
    </>
  );
}

function CategoryCard({ c, meta, metaObj }) {
  const [open, setOpen] = useStateC(false);
  const subs = c.subs || [];
  const subCount = subs.length;
  return (
    <div className={"cfg-cat-card " + (open ? "cfg-cat-card-open" : "")} style={{ "--cat-color": meta.color }}>
      <div className="cfg-cat-card-bar" />
      <div className="cfg-cat-card-head">
        <div className="cfg-cat-card-icon" style={{ background: meta.color + "25", color: meta.color }}>
          <Icon name={meta.icon} size={18} />
        </div>
        <div className="cfg-cat-card-name">{meta.label}</div>
        <div className="cfg-cat-card-actions">
          <button className="btn-icon" title="Editar"><Icon name="edit" size={14} /></button>
          <button className="btn-icon" title="Excluir"><Icon name="delete" size={14} /></button>
        </div>
      </div>
      <div className="cfg-cat-card-badges">
        {c.limite && (
          <span className="cfg-badge">
            <Icon name="speed" size={12} /> {brlCompact(-c.limite)}/mês
          </span>
        )}
        {metaObj && (
          <span className="cfg-badge cfg-badge-meta" style={{ color: metaObj.cor, borderColor: metaObj.cor + "40", background: metaObj.cor + "12" }}>
            <Icon name="flag" size={12} /> {metaObj.nome}
          </span>
        )}
        {c.excluirTotais && (
          <span className="cfg-badge cfg-badge-warn">
            <Icon name="visibility_off" size={12} /> Fora dos totais
          </span>
        )}
        {!c.limite && !metaObj && !c.excluirTotais && (
          <span className="t-xs t-muted">Sem regras especiais</span>
        )}
      </div>

      <button className="cfg-sub-toggle" onClick={() => setOpen(!open)}>
        <Icon name={open ? "expand_less" : "expand_more"} size={16} />
        <span>{subCount > 0 ? `${subCount} subcategoria${subCount > 1 ? "s" : ""}` : "Adicionar subcategoria"}</span>
        {!open && subCount > 0 && (
          <div className="cfg-sub-preview">
            {subs.slice(0, 4).map(s => (
              <div key={s.id} className="cfg-sub-dot" style={{ background: meta.color + "30", color: meta.color }} title={s.nome}>
                <Icon name={s.icon} size={11} />
              </div>
            ))}
            {subs.length > 4 && <div className="cfg-sub-more">+{subs.length - 4}</div>}
          </div>
        )}
      </button>

      {open && (
        <div className="cfg-sub-list">
          {subs.map(s => (
            <div key={s.id} className="cfg-sub-row">
              <div className="cfg-sub-icon" style={{ background: meta.color + "20", color: meta.color }}>
                <Icon name={s.icon} size={13} />
              </div>
              <div className="cfg-sub-name">{s.nome}</div>
              <div className="cfg-sub-meta">
                <span className="cfg-sub-meta-item" title="Palavras-chave">
                  <Icon name="key" size={11} /> {s.keywords}
                </span>
                <span className="cfg-sub-meta-item" title="Transações no ciclo">
                  <Icon name="receipt_long" size={11} /> {s.count}
                </span>
              </div>
              <button className="btn-icon btn-icon-sm"><Icon name="edit" size={12} /></button>
              <button className="btn-icon btn-icon-sm"><Icon name="close" size={12} /></button>
            </div>
          ))}
          <button className="cfg-sub-add">
            <Icon name="add" size={14} /> Nova subcategoria
          </button>
        </div>
      )}
    </div>
  );
}
// ============ Sistema ============
function SistemaSection() {
  const [pasta, setPasta] = useStateC("C:\\Users\\fabio\\Documents\\Financeiro\\Importacoes");
  const [diaCiclo, setDiaCiclo] = useStateC(27);

  return (
    <>
      <div className="cfg-section-head">
        <div>
          <div className="cfg-section-title">Sistema</div>
          <div className="t-xs t-muted">Ajustes gerais do app</div>
        </div>
      </div>

      <Glass>
        <div className="cfg-form">
          <div className="cfg-field">
            <label className="cfg-label">
              <Icon name="folder" size={16} /> Pasta de importação padrão
            </label>
            <div className="cfg-hint">Caminho onde o app procura novos extratos automaticamente</div>
            <div className="cfg-input-row">
              <input
                className="cfg-input"
                value={pasta}
                onChange={e => setPasta(e.target.value)}
              />
              <button className="btn-ghost"><Icon name="folder_open" size={14} /> Procurar</button>
            </div>
          </div>

          <div className="cfg-field">
            <label className="cfg-label">
              <Icon name="event" size={16} /> Dia de início do ciclo
            </label>
            <div className="cfg-hint">Define o período mensal usado nos relatórios (ex: 27 → 26)</div>
            <div className="cfg-input-row">
              <input
                type="number" min="1" max="28"
                className="cfg-input cfg-input-num"
                value={diaCiclo}
                onChange={e => setDiaCiclo(+e.target.value)}
              />
              <span className="t-sm t-muted">do mês</span>
            </div>
          </div>

          <div className="cfg-form-foot">
            <button className="btn-primary"><Icon name="save" size={14} /> Salvar alterações</button>
          </div>
        </div>
      </Glass>
    </>
  );
}

// ============ Zona de Perigo ============
function ZonaPerigoSection() {
  const [confirmando, setConfirmando] = useStateC(false);
  const [texto, setTexto] = useStateC("");
  const palavraConfirmar = "LIMPAR TUDO";

  return (
    <>
      <div className="cfg-section-head">
        <div>
          <div className="cfg-section-title cfg-danger-title">
            <Icon name="warning" size={18} /> Zona de Perigo
          </div>
          <div className="t-xs t-muted">Ações irreversíveis — proceda com cuidado</div>
        </div>
      </div>

      <div className="cfg-danger-card">
        <div className="cfg-danger-icon">
          <Icon name="delete_forever" size={24} />
        </div>
        <div style={{ flex: 1 }}>
          <div className="cfg-danger-h">Limpar todas as transações e faturas</div>
          <div className="cfg-danger-p">
            Remove permanentemente todos os extratos importados, faturas, categorizações e
            vínculos com provisões. <strong>Pessoas, cartões, categorias, regras e provisões serão
            preservados.</strong> Esta ação não pode ser desfeita.
          </div>

          {!confirmando ? (
            <button className="btn-danger-outline" onClick={() => setConfirmando(true)}>
              <Icon name="delete_forever" size={14} /> Limpar todas as transações
            </button>
          ) : (
            <div className="cfg-danger-confirm">
              <div className="t-xs t-muted">
                Para confirmar, digite <code>{palavraConfirmar}</code> no campo abaixo:
              </div>
              <div className="cfg-input-row">
                <input
                  className="cfg-input cfg-input-danger"
                  value={texto}
                  onChange={e => setTexto(e.target.value)}
                  placeholder={palavraConfirmar}
                />
                <button className="btn-ghost" onClick={() => { setConfirmando(false); setTexto(""); }}>
                  Cancelar
                </button>
                <button
                  className="btn-danger"
                  disabled={texto !== palavraConfirmar}
                  onClick={() => { setConfirmando(false); setTexto(""); }}
                >
                  <Icon name="delete_forever" size={14} /> Confirmar exclusão
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

Object.assign(window, { Config });
