// Importar — drag-drop intake with file detection + dedupe simulation
const { useState: useStateI } = React;

const SAMPLE_IMPORTS = [
  { id: "f1", nome: "extrato_itau_abr2026.ofx",        tipo: "OFX",   fonte: "Itaú · Conta Corrente", transacoes: 47, novas: 47, dup: 0,  status: "ok" },
  { id: "f2", nome: "fatura_itau_mai2026.pdf",         tipo: "PDF",   fonte: "Itaú · Cartão Visa",    transacoes: 32, novas: 28, dup: 4,  status: "ok" },
  { id: "f3", nome: "extrato_corrente_mai_parcial.xls",tipo: "Excel", fonte: "Itaú · Conta Corrente", transacoes: 12, novas:  9, dup: 3,  status: "ok" },
];

function Importar({ onNav }) {
  const [drag, setDrag] = useStateI(false);
  const [importados, setImportados] = useStateI(SAMPLE_IMPORTS);
  const [novo, setNovo] = useStateI(null);

  const totalNovas = importados.reduce((s, f) => s + f.novas, 0);
  const totalDup = importados.reduce((s, f) => s + f.dup, 0);

  const fakeAdd = () => {
    const f = {
      id: "fx" + Date.now(),
      nome: "fatura_itau_jun2026.pdf",
      tipo: "PDF",
      fonte: "Itaú · Cartão Visa",
      transacoes: 28, novas: 25, dup: 3, status: "novo",
    };
    setImportados([f, ...importados]);
    setNovo(f.id);
    setTimeout(() => setNovo(null), 1800);
  };

  return (
    <div className="page page-importar">
      <PageHeader
        title="Importar"
        subtitle="OFX, Excel ou PDF — o app detecta a origem e remove duplicatas automaticamente"
      />

      <Glass
        className={"dropzone " + (drag ? "dropzone-drag" : "")}
        padded={false}
        onClick={fakeAdd}
      >
        <div
          onDragOver={e => { e.preventDefault(); setDrag(true); }}
          onDragLeave={() => setDrag(false)}
          onDrop={e => { e.preventDefault(); setDrag(false); fakeAdd(); }}
          className="dropzone-inner"
        >
          <div className="dropzone-icon">
            <Icon name="upload_file" size={36} />
          </div>
          <div className="dropzone-title">Arraste arquivos ou clique para selecionar</div>
          <div className="dropzone-sub">Suporta OFX (banco), Excel (Itaú) e PDF (fatura). Múltiplos arquivos.</div>
          <div className="dropzone-tags">
            <span className="tag"><Icon name="description" size={14} />OFX</span>
            <span className="tag"><Icon name="grid_on" size={14} />XLSX</span>
            <span className="tag"><Icon name="picture_as_pdf" size={14} />PDF</span>
          </div>
        </div>
      </Glass>

      <div className="grid-3">
        <Glass className="stat-card">
          <div className="stat-label">ARQUIVOS PROCESSADOS</div>
          <div className="stat-val">{importados.length}</div>
          <div className="t-xs t-muted">Neste ciclo</div>
        </Glass>
        <Glass className="stat-card">
          <div className="stat-label">NOVAS TRANSAÇÕES</div>
          <div className="stat-val" style={{ color: "#22C55E" }}>+{totalNovas}</div>
          <div className="t-xs t-muted">Adicionadas ao livro</div>
        </Glass>
        <Glass className="stat-card">
          <div className="stat-label">DUPLICATAS IGNORADAS</div>
          <div className="stat-val" style={{ color: "#94A3B8" }}>{totalDup}</div>
          <div className="t-xs t-muted">Detectadas por hash + valor + data</div>
        </Glass>
      </div>

      <Glass>
        <SectionHeader
          title="Histórico de importações"
          right={
            <button className="btn-ghost" onClick={() => onNav("transacoes")}>
              Ver transações <Icon name="arrow_forward" size={14} />
            </button>
          }
        />
        <div className="imp-list">
          {importados.map(f => (
            <div key={f.id} className={"imp-row " + (novo === f.id ? "imp-row-new" : "")}>
              <div className="imp-icon" style={{ background: f.tipo === "OFX" ? "#06B6D420" : f.tipo === "PDF" ? "#EC489920" : "#22C55E20", color: f.tipo === "OFX" ? "#06B6D4" : f.tipo === "PDF" ? "#EC4899" : "#22C55E" }}>
                <Icon name={f.tipo === "OFX" ? "description" : f.tipo === "PDF" ? "picture_as_pdf" : "grid_on"} size={20} />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="t-sm">{f.nome}</div>
                <div className="t-xs t-muted">{f.fonte} · {f.transacoes} transações lidas</div>
              </div>
              <div className="imp-stats">
                <span className="imp-pill imp-pill-new">+{f.novas} novas</span>
                {f.dup > 0 && <span className="imp-pill imp-pill-dup">{f.dup} dup.</span>}
              </div>
              <button className="btn-icon"><Icon name="more_vert" size={18} /></button>
            </div>
          ))}
        </div>
      </Glass>

      <Glass className="hint-card">
        <Icon name="lightbulb" size={20} className="hint-icon" />
        <div>
          <div className="t-sm">Dica</div>
          <div className="t-xs t-muted">
            Importe extratos no início de cada ciclo (dia 27). O app reconhece o formato automaticamente
            e ignora arquivos já processados.
          </div>
        </div>
      </Glass>
    </div>
  );
}

Object.assign(window, { Importar });
