// Stub pages for sidebar items not designed in detail
function StubPage({ titulo, subtitulo, icon, children }) {
  return (
    <div className="page page-stub">
      <PageHeader title={titulo} subtitle={subtitulo} />
      <Glass className="stub-card">
        <div className="stub-icon">
          <Icon name={icon} size={40} />
        </div>
        <div className="stub-title">{titulo}</div>
        <div className="stub-sub">{subtitulo}</div>
        {children}
      </Glass>
    </div>
  );
}

function Cartao() {
  return (
    <div className="page page-cartao">
      <PageHeader title="Cartão" subtitle="Fatura aberta · vence 15/mai" />
      <div className="grid-2">
        <Glass className="cartao-card">
          <div className="cartao-bg">
            <div className="cartao-net">VISA</div>
            <div className="cartao-num">•••• •••• •••• 4291</div>
            <div className="cartao-foot">
              <div>
                <div className="t-xs t-muted">TITULAR</div>
                <div className="t-sm">FABIO ALMEIDA</div>
              </div>
              <div>
                <div className="t-xs t-muted">VAL</div>
                <div className="t-sm">12/29</div>
              </div>
            </div>
          </div>
          <div className="cartao-info">
            <div className="t-xs t-muted">FATURA ABERTA</div>
            <div className="cartao-val">R$ 1.847,30</div>
            <div className="t-xs t-muted">de R$ 8.000,00 de limite</div>
            <div className="cartao-bar">
              <div className="cartao-bar-fill" style={{ width: "23%" }} />
            </div>
          </div>
        </Glass>
        <Glass>
          <SectionHeader title="Próximas faturas" />
          <div className="t-sm t-muted" style={{ padding: "20px 0" }}>Esta tela ainda será detalhada na próxima iteração.</div>
        </Glass>
      </div>
    </div>
  );
}

function Metas() {
  const [sel, setSel] = React.useState(null);
  return (
    <div className="page page-metas">
      <PageHeader title="Metas & Cofrinhos" subtitle="Onde seu dinheiro está sendo guardado" right={<button className="btn-primary"><Icon name="add" size={14} />Nova meta</button>} />
      <div className="grid-3">
        {METAS.map(m => {
          const pct = (m.atual / m.alvo) * 100;
          return (
            <Glass key={m.id} className="meta-card meta-card-clickable" onClick={() => setSel(m)}>
              <div className="meta-card-icon" style={{ background: m.cor + "25", color: m.cor }}>
                <Icon name={m.icon} size={28} />
              </div>
              <div className="meta-card-name">{m.nome}</div>
              <div className="meta-card-val">{brl(m.atual)}</div>
              <div className="meta-card-alvo">de {brl(m.alvo)}</div>
              <div className="meta-bar"><div className="meta-fill" style={{ width: pct + "%", background: m.cor }} /></div>
              <div className="t-xs t-muted">{Math.round(pct)}% concluído · faltam {brlCompact(m.alvo - m.atual)}</div>
              <div className="meta-card-hint">
                <Icon name="open_in_full" size={12} /> Ver detalhes
              </div>
            </Glass>
          );
        })}
      </div>
      {sel && <MetaDetailModal meta={sel} onClose={() => setSel(null)} />}
    </div>
  );
}

function MetaDetailModal({ meta, onClose }) {
  const [confirmDelete, setConfirmDelete] = React.useState(false);
  const pct = (meta.atual / meta.alvo) * 100;
  const falta = meta.alvo - meta.atual;
  // Synthetic monthly aporte history
  const historico = [
    { mes: "dez/25", valor: 1200, origem: "Cofrinho automático (10% do salário)" },
    { mes: "jan/26", valor: 1500, origem: "Cofrinho automático + extra manual" },
    { mes: "fev/26", valor: 1200, origem: "Cofrinho automático" },
    { mes: "mar/26", valor: 1800, origem: "Cofrinho + 13º proporcional" },
    { mes: "abr/26", valor: 1200, origem: "Cofrinho automático" },
  ];
  const aporteMedio = historico.reduce((s, h) => s + h.valor, 0) / historico.length;
  const mesesParaConcluir = Math.ceil(falta / aporteMedio);

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal modal-lg" onClick={e => e.stopPropagation()}>
        <div className="modal-head">
          <div style={{ display: "flex", gap: 14, alignItems: "center" }}>
            <div className="meta-card-icon" style={{ background: meta.cor + "25", color: meta.cor, width: 48, height: 48 }}>
              <Icon name={meta.icon} size={24} />
            </div>
            <div>
              <div className="modal-title">{meta.nome}</div>
              <div className="t-xs t-muted">Meta · cofrinho automático ativo</div>
            </div>
          </div>
          <button className="btn-icon" onClick={onClose}><Icon name="close" size={20} /></button>
        </div>

        <div className="modal-body">
          {/* Progress hero */}
          <div className="meta-detail-hero">
            <div className="meta-detail-row">
              <div>
                <div className="t-xs t-muted">GUARDADO</div>
                <div className="meta-detail-val" style={{ color: meta.cor }}>{brl(meta.atual)}</div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div className="t-xs t-muted">META</div>
                <div className="meta-detail-val">{brl(meta.alvo)}</div>
              </div>
            </div>
            <div className="meta-bar meta-bar-lg">
              <div className="meta-fill" style={{ width: pct + "%", background: meta.cor }} />
            </div>
            <div className="meta-detail-row" style={{ marginTop: 4 }}>
              <span className="t-sm" style={{ color: meta.cor, fontWeight: 600 }}>{Math.round(pct)}% concluído</span>
              <span className="t-sm t-muted">faltam {brl(falta)}</span>
            </div>
          </div>

          {/* Stats */}
          <div className="grid-3">
            <div className="meta-stat">
              <div className="t-xs t-muted">APORTE MÉDIO/MÊS</div>
              <div className="meta-stat-val">{brl(aporteMedio)}</div>
            </div>
            <div className="meta-stat">
              <div className="t-xs t-muted">PREVISÃO</div>
              <div className="meta-stat-val">{mesesParaConcluir} meses</div>
              <div className="t-xs t-muted">no ritmo atual</div>
            </div>
            <div className="meta-stat">
              <div className="t-xs t-muted">REGRA AUTO</div>
              <div className="meta-stat-val" style={{ fontSize: 16 }}>10% do salário</div>
              <div className="t-xs t-muted">todo dia 5</div>
            </div>
          </div>

          {/* Histórico de aportes */}
          <div>
            <div className="cfg-label" style={{ marginBottom: 10 }}>HISTÓRICO DE APORTES</div>
            <div className="meta-historico">
              {historico.slice().reverse().map((h, i) => (
                <div key={i} className="meta-aporte-row">
                  <div className="t-xs t-muted" style={{ width: 56, fontFamily: "ui-monospace, monospace" }}>{h.mes}</div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div className="t-sm">{h.origem}</div>
                  </div>
                  <div className="t-sm" style={{ color: meta.cor, fontWeight: 600, fontVariantNumeric: "tabular-nums" }}>
                    +{brl(h.valor)}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick action */}
          <button className="meta-add-aporte">
            <Icon name="add_circle" size={18} />
            <span>Fazer aporte manual</span>
          </button>
        </div>

        <div className="modal-foot modal-foot-split">
          {!confirmDelete ? (
            <>
              <button className="btn-danger-ghost" onClick={() => setConfirmDelete(true)}>
                <Icon name="delete" size={14} /> Excluir
              </button>
              <div style={{ display: "flex", gap: 8 }}>
                <button className="btn-ghost" onClick={onClose}>Fechar</button>
                <button className="btn-primary">
                  <Icon name="edit" size={14} /> Editar meta
                </button>
              </div>
            </>
          ) : (
            <>
              <div className="t-sm" style={{ color: "#FCA5A5" }}>
                <Icon name="warning" size={14} /> Excluir esta meta? O valor guardado será liberado.
              </div>
              <div style={{ display: "flex", gap: 8 }}>
                <button className="btn-ghost" onClick={() => setConfirmDelete(false)}>Cancelar</button>
                <button className="btn-danger" onClick={onClose}>
                  <Icon name="delete_forever" size={14} /> Confirmar exclusão
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function Regras() {
  const regras = [
    { keyword: "PAO DE ACUCAR", cat: "mercado", count: 12 },
    { keyword: "IFOOD", cat: "restaurante", count: 28 },
    { keyword: "UBER", cat: "transporte", count: 47 },
    { keyword: "NETFLIX", cat: "assinatura", count: 4 },
    { keyword: "DROGARIA", cat: "saude", count: 9 },
  ];
  return (
    <div className="page page-regras">
      <PageHeader title="Regras de categorização" subtitle="Quando uma transação contém o keyword, ela é auto-categorizada" right={<button className="btn-primary"><Icon name="add" size={14} />Nova regra</button>} />
      <Glass padded={false}>
        <div className="lista-prov">
          <div className="lista-prov-head" style={{ gridTemplateColumns: "2fr 1.5fr 1fr 0.5fr" }}>
            <div>Quando descrição contém</div>
            <div>Categorizar como</div>
            <div>Aplicada em</div>
            <div></div>
          </div>
          {regras.map((r, i) => (
            <div key={i} className="lista-prov-row" style={{ gridTemplateColumns: "2fr 1.5fr 1fr 0.5fr" }}>
              <div className="t-sm" style={{ fontFamily: "ui-monospace, monospace" }}>"{r.keyword}"</div>
              <div><CategoriaChip id={r.cat} /></div>
              <div className="t-xs t-muted">{r.count} transações</div>
              <div><button className="btn-icon"><Icon name="more_vert" size={16} /></button></div>
            </div>
          ))}
        </div>
      </Glass>
    </div>
  );
}

function ConfigStub() {
  return <StubPage titulo="Configurações" subtitulo="Contas, ciclo, exportação, backup" icon="settings" />;
}

Object.assign(window, { Cartao, Metas, MetaDetailModal, Regras, ConfigStub, StubPage });
