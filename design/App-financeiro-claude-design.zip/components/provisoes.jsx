// Provisões — calendar of recurring expenses + month-by-month projection
const { useState: useStateP, useMemo: useMemoP } = React;

function Provisoes({ onNav }) {
  const [view, setView] = useStateP("timeline"); // timeline | calendario | lista
  const [selMes, setSelMes] = useStateP(0);
  const [showModal, setShowModal] = useStateP(false);

  const meses = useMemoP(() => {
    const out = [];
    const labels = ["mai/26","jun/26","jul/26","ago/26","set/26","out/26"];
    for (let i = 0; i < 6; i++) {
      const items = PROVISOES.filter(p => {
        if (p.tipo === "parcela") return p.parcelas.atual + i <= p.parcelas.total;
        return true;
      }).map(p => ({ ...p, parcelaIdx: p.tipo === "parcela" ? p.parcelas.atual + i : null }));
      const total = items.reduce((s, p) => s + p.valor, 0);
      const compromisso = -items.filter(p => p.valor < 0).reduce((s, p) => s + p.valor, 0);
      const receita = items.filter(p => p.valor > 0).reduce((s, p) => s + p.valor, 0);
      out.push({ label: labels[i], items, total, compromisso, receita });
    }
    return out;
  }, []);

  return (
    <div className="page page-provisoes">
      <PageHeader
        title="Provisões"
        subtitle="Receitas e despesas recorrentes que ainda vão acontecer"
        right={
          <div className="seg-control">
            <button className={view === "timeline" ? "seg-on" : ""} onClick={() => setView("timeline")}>
              <Icon name="timeline" size={16} /> Timeline
            </button>
            <button className={view === "calendario" ? "seg-on" : ""} onClick={() => setView("calendario")}>
              <Icon name="calendar_month" size={16} /> Calendário
            </button>
            <button className={view === "lista" ? "seg-on" : ""} onClick={() => setView("lista")}>
              <Icon name="list" size={16} /> Lista
            </button>
          </div>
        }
      />

      {/* Resumo */}
      <div className="grid-3">
        <Glass className="stat-card">
          <div className="stat-label">PROVISÕES ATIVAS</div>
          <div className="stat-val">{PROVISOES.filter(p => p.ativa).length}</div>
          <div className="t-xs t-muted">{PROVISOES.filter(p => p.tipo === "parcela").length} parcelas + {PROVISOES.filter(p => p.tipo === "mensal").length} mensais</div>
        </Glass>
        <Glass className="stat-card">
          <div className="stat-label">COMPROMETIDO / MÊS</div>
          <div className="stat-val" style={{ color: "#F472B6" }}>{brl(-meses[0].compromisso)}</div>
          <div className="t-xs t-muted">Soma das despesas recorrentes</div>
        </Glass>
        <Glass className="stat-card">
          <div className="stat-label">RECEITAS ESPERADAS / MÊS</div>
          <div className="stat-val" style={{ color: "#22C55E" }}>{brl(meses[0].receita)}</div>
          <div className="t-xs t-muted">Salário + recorrentes</div>
        </Glass>
      </div>

      {view === "timeline" && <TimelineView meses={meses} sel={selMes} onSel={setSelMes} onAdd={() => setShowModal(true)} />}
      {view === "calendario" && <CalendarView mes={meses[0]} />}
      {view === "lista" && <ListaView onAdd={() => setShowModal(true)} />}

      {showModal && <NovaProvisaoModal onClose={() => setShowModal(false)} />}
    </div>
  );
}

function TimelineView({ meses, sel, onSel, onAdd }) {
  const m = meses[sel];
  return (
    <>
      <Glass>
        <SectionHeader title="6 meses à frente" hint="Clique em um mês para ver os eventos" />
        <div className="timeline-strip">
          {meses.map((mes, i) => (
            <button
              key={i}
              className={"timeline-month " + (sel === i ? "timeline-month-on" : "")}
              onClick={() => onSel(i)}
            >
              <div className="timeline-month-label">{mes.label}</div>
              <div className="timeline-bars">
                <div className="timeline-bar timeline-bar-out" style={{ height: Math.min(100, (mes.compromisso / 6000) * 100) + "%" }} />
                <div className="timeline-bar timeline-bar-in" style={{ height: Math.min(100, (mes.receita / 10000) * 100) + "%" }} />
              </div>
              <div className="timeline-month-total" style={{ color: mes.total >= 0 ? "#22C55E" : "#F472B6" }}>
                {mes.total >= 0 ? "+" : ""}{brlCompact(mes.total)}
              </div>
            </button>
          ))}
        </div>
      </Glass>

      <Glass>
        <SectionHeader
          title={`Eventos em ${m.label}`}
          hint={`${m.items.length} ocorrências · saldo do mês ${m.total >= 0 ? "+" : ""}${brl(m.total)}`}
          right={<button className="btn-primary" onClick={onAdd}><Icon name="add" size={14} />Nova provisão</button>}
        />
        <div className="prov-list">
          {[...m.items].sort((a, b) => a.dia - b.dia).map(p => {
            const c = CATEGORIAS[p.categoria];
            const realizada = p.dia <= HOJE.getDate() && sel === 0;
            return (
              <div key={p.id + sel} className={"prov-row " + (realizada ? "prov-row-done" : "")}>
                <div className="prov-day">
                  <div className="prov-day-num">{p.dia}</div>
                  <div className="prov-day-mes">{m.label.split("/")[0]}</div>
                </div>
                <div className="prov-icon" style={{ background: c.color + "20", color: c.color }}>
                  <Icon name={c.icon} size={18} />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div className="t-sm">{p.desc}{p.parcelaIdx ? ` (${p.parcelaIdx}/${p.parcelas.total})` : ""}</div>
                  <div className="prov-row-meta">
                    <CategoriaChip id={p.categoria} />
                    <span className="t-xs t-muted">{p.tipo === "mensal" ? "Mensal" : "Parcela"}</span>
                  </div>
                </div>
                <div className={"prov-val " + (p.valor > 0 ? "tx-val-pos" : "")}>
                  {brl(p.valor)}
                </div>
                <div className="prov-status">
                  {realizada ? (
                    <span className="prov-tag prov-tag-done">
                      <Icon name="check_circle" size={14} /> Realizada
                    </span>
                  ) : (
                    <button className="btn-ghost btn-ghost-sm">
                      <Icon name="link" size={14} /> Vincular
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </Glass>
    </>
  );
}

function CalendarView({ mes }) {
  // simple month grid for May 2026
  const days = Array.from({ length: 31 }, (_, i) => i + 1);
  const startDow = 5; // May 1 2026 is Friday (5)
  const cells = Array.from({ length: startDow }, () => null).concat(days);
  const eventsByDay = {};
  mes.items.forEach(p => { (eventsByDay[p.dia] = eventsByDay[p.dia] || []).push(p); });

  return (
    <Glass>
      <SectionHeader title={mes.label} hint="Eventos recorrentes neste mês" />
      <div className="cal-grid">
        {["DOM","SEG","TER","QUA","QUI","SEX","SÁB"].map(d => (
          <div key={d} className="cal-dow">{d}</div>
        ))}
        {cells.map((d, i) => {
          if (d === null) return <div key={i} className="cal-cell cal-cell-empty" />;
          const evs = eventsByDay[d] || [];
          const hoje = d === HOJE.getDate();
          return (
            <div key={i} className={"cal-cell " + (hoje ? "cal-cell-today" : "")}>
              <div className="cal-day-num">{d}</div>
              {evs.slice(0, 3).map(p => {
                const c = CATEGORIAS[p.categoria];
                return (
                  <div key={p.id} className="cal-ev" style={{ background: c.color + "25", borderLeft: `2px solid ${c.color}` }}>
                    <span style={{ color: c.color, fontWeight: 600 }}>{brlCompact(p.valor)}</span>
                    <span className="t-muted-2">{p.desc.split(" ")[0]}</span>
                  </div>
                );
              })}
              {evs.length > 3 && <div className="t-xs t-muted">+{evs.length - 3} mais</div>}
            </div>
          );
        })}
      </div>
    </Glass>
  );
}

function ListaView({ onAdd }) {
  return (
    <Glass>
      <SectionHeader
        title="Todas as provisões"
        right={<button className="btn-primary" onClick={onAdd}><Icon name="add" size={14} />Nova provisão</button>}
      />
      <div className="lista-prov">
        <div className="lista-prov-head">
          <div>Descrição</div>
          <div>Categoria</div>
          <div>Tipo</div>
          <div>Dia</div>
          <div>Valor</div>
          <div></div>
        </div>
        {PROVISOES.map(p => {
          const c = CATEGORIAS[p.categoria];
          return (
            <div key={p.id} className="lista-prov-row">
              <div className="t-sm">{p.desc}</div>
              <div><CategoriaChip id={p.categoria} /></div>
              <div className="t-xs t-muted">
                {p.tipo === "parcela" ? `Parcela ${p.parcelas.atual}/${p.parcelas.total}` : "Mensal"}
              </div>
              <div className="t-xs t-muted">dia {p.dia}</div>
              <div className={"t-sm " + (p.valor > 0 ? "tx-val-pos" : "")} style={{ fontVariantNumeric: "tabular-nums" }}>
                {brl(p.valor)}
              </div>
              <div>
                <button className="btn-icon"><Icon name="more_vert" size={16} /></button>
              </div>
            </div>
          );
        })}
      </div>
    </Glass>
  );
}

// ============ Modal ============
function NovaProvisaoModal({ onClose }) {
  const [tipo, setTipoP] = useStateP("despesa");
  const [recorrencia, setRecorrencia] = useStateP("mensal");
  const [desc, setDesc] = useStateP("");
  const [valor, setValor] = useStateP("");
  const [dia, setDia] = useStateP(5);
  const [categoria, setCategoria] = useStateP("casa");
  const [parcelas, setParcelas] = useStateP(12);

  const cats = Object.entries(CATEGORIAS).filter(([k]) => {
    if (tipo === "receita") return ["salario", "freelance", "outros"].includes(k);
    return !["salario", "freelance", "transferencia"].includes(k);
  });

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-head">
          <div>
            <div className="modal-title">Nova provisão</div>
            <div className="t-xs t-muted">Receita ou despesa recorrente que ainda vai acontecer</div>
          </div>
          <button className="btn-icon" onClick={onClose}><Icon name="close" size={20} /></button>
        </div>

        <div className="modal-body">
          <div className="cfg-field">
            <label className="cfg-label">Tipo</label>
            <div className="seg-control" style={{ alignSelf: "start" }}>
              <button className={tipo === "despesa" ? "seg-on" : ""} onClick={() => setTipoP("despesa")}>
                <Icon name="trending_down" size={14} /> Despesa
              </button>
              <button className={tipo === "receita" ? "seg-on" : ""} onClick={() => setTipoP("receita")}>
                <Icon name="trending_up" size={14} /> Receita
              </button>
            </div>
          </div>

          <div className="cfg-field">
            <label className="cfg-label">Descrição</label>
            <input className="cfg-input" style={{ fontFamily: "inherit" }}
              placeholder="Ex: Netflix, Aluguel, Salário..."
              value={desc} onChange={e => setDesc(e.target.value)} autoFocus />
          </div>

          <div className="modal-row">
            <div className="cfg-field" style={{ flex: 1 }}>
              <label className="cfg-label">Valor</label>
              <div className="cfg-input-row">
                <span className="modal-prefix">R$</span>
                <input className="cfg-input" placeholder="0,00"
                  value={valor} onChange={e => setValor(e.target.value)}
                  style={{ fontFamily: "ui-monospace, monospace" }} />
              </div>
            </div>
            <div className="cfg-field" style={{ flex: 0 }}>
              <label className="cfg-label">Dia do mês</label>
              <input type="number" min="1" max="28"
                className="cfg-input cfg-input-num"
                value={dia} onChange={e => setDia(+e.target.value)} />
            </div>
          </div>

          <div className="cfg-field">
            <label className="cfg-label">Recorrência</label>
            <div className="seg-control" style={{ alignSelf: "start" }}>
              <button className={recorrencia === "mensal" ? "seg-on" : ""} onClick={() => setRecorrencia("mensal")}>
                <Icon name="event_repeat" size={14} /> Mensal contínua
              </button>
              <button className={recorrencia === "parcela" ? "seg-on" : ""} onClick={() => setRecorrencia("parcela")}>
                <Icon name="format_list_numbered" size={14} /> Parcelada
              </button>
            </div>
            {recorrencia === "parcela" && (
              <div className="cfg-input-row" style={{ marginTop: 8 }}>
                <span className="t-sm t-muted">em</span>
                <input type="number" min="2" max="120"
                  className="cfg-input cfg-input-num"
                  value={parcelas} onChange={e => setParcelas(+e.target.value)} />
                <span className="t-sm t-muted">parcelas mensais</span>
              </div>
            )}
          </div>

          <div className="cfg-field">
            <label className="cfg-label">Categoria</label>
            <div className="modal-cat-grid">
              {cats.map(([k, c]) => (
                <button key={k}
                  className={"inbox-cat " + (k === categoria ? "inbox-cat-suggest" : "")}
                  onClick={() => setCategoria(k)}>
                  <Icon name={c.icon} size={16} style={{ color: c.color }} />
                  <span>{c.label}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="modal-preview">
            <div className="t-xs t-muted">PRÉ-VISUALIZAÇÃO</div>
            <div className="modal-preview-row">
              <div className="prov-day">
                <div className="prov-day-num">{dia}</div>
                <div className="prov-day-mes">de cada mês</div>
              </div>
              <div className="prov-icon" style={{ background: CATEGORIAS[categoria].color + "20", color: CATEGORIAS[categoria].color }}>
                <Icon name={CATEGORIAS[categoria].icon} size={18} />
              </div>
              <div style={{ flex: 1 }}>
                <div className="t-sm">{desc || "Sem descrição"}</div>
                <div className="prov-row-meta">
                  <CategoriaChip id={categoria} />
                  <span className="t-xs t-muted">
                    {recorrencia === "mensal" ? "Mensal contínua" : `Parcela 1/${parcelas}`}
                  </span>
                </div>
              </div>
              <div className={"prov-val " + (tipo === "receita" ? "tx-val-pos" : "")}>
                {tipo === "receita" ? "+" : "-"}R$ {valor || "0,00"}
              </div>
            </div>
          </div>
        </div>

        <div className="modal-foot">
          <button className="btn-ghost" onClick={onClose}>Cancelar</button>
          <button className="btn-primary" onClick={onClose} disabled={!desc || !valor}>
            <Icon name="check" size={14} /> Criar provisão
          </button>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Provisoes });