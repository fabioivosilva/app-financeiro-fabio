// Dashboard — month at a glance + future projection
const { useState: useStateD, useMemo: useMemoD } = React;

function Dashboard({ onNav }) {
  // ---------- compute current cycle metrics ----------
  const { receitas, gastos, gastosPorCat, topGastos, pendentes, alertas } = useMemoD(() => {
    const ok = TRANSACOES.filter(t => t.status === "ok");
    const receitas = ok.filter(t => t.valor > 0).reduce((s, t) => s + t.valor, 0);
    const gastos = -ok.filter(t => t.valor < 0).reduce((s, t) => s + t.valor, 0);

    const byCat = {};
    ok.filter(t => t.valor < 0).forEach(t => {
      byCat[t.categoria] = (byCat[t.categoria] || 0) + (-t.valor);
    });
    const gastosPorCat = Object.entries(byCat)
      .map(([id, v]) => ({ id, valor: v, ...CATEGORIAS[id] }))
      .sort((a, b) => b.valor - a.valor);

    const topGastos = ok.filter(t => t.valor < 0).sort((a, b) => a.valor - b.valor).slice(0, 5);
    const pendentes = TRANSACOES.filter(t => t.status === "pendente").length;

    const alertas = [];
    Object.entries(ORCAMENTOS).forEach(([cat, limite]) => {
      const usado = byCat[cat] || 0;
      const pct = usado / limite;
      if (pct >= 0.85) alertas.push({ cat, usado, limite, pct });
    });

    return { receitas, gastos, gastosPorCat, topGastos, pendentes, alertas };
  }, []);

  // ---------- saldo projetado: gastos do ciclo + provisões que ainda não vieram ----------
  const saldoAtual = receitas - gastos;
  const provisoesRestantes = useMemoD(() => {
    // provisões cujo dia ainda não passou no ciclo atual
    const hojeDia = HOJE.getDate();
    return PROVISOES.filter(p => {
      // dia 27-31 = no início do ciclo (já passou); 1-26 = se >= hoje, falta
      if (p.dia >= 27) return false; // já passou (foi no início do ciclo)
      if (p.dia < hojeDia) return false;
      // só conta se ainda não foi vinculada a uma transação real
      const jaImportada = TRANSACOES.some(t => t.provisao === p.id);
      return !jaImportada;
    });
  }, []);
  const compromissoRestante = -provisoesRestantes.filter(p => p.valor < 0).reduce((s, p) => s + p.valor, 0);
  const receitaRestante     =  provisoesRestantes.filter(p => p.valor > 0).reduce((s, p) => s + p.valor, 0);
  const saldoProjetado = saldoAtual - compromissoRestante + receitaRestante;

  // ---------- 6-month projection ----------
  const projecao = useMemoD(() => {
    const meses = [];
    let saldoAcum = saldoAtual;
    const labelsM = ["mai/26","jun/26","jul/26","ago/26","set/26","out/26"];
    for (let i = 0; i < 6; i++) {
      // soma de provisões em um mês cheio
      const totalProv = PROVISOES.reduce((s, p) => {
        if (p.tipo === "parcela" && p.parcelas.atual + i > p.parcelas.total) return s;
        return s + p.valor;
      }, 0);
      if (i === 0) {
        // primeiro mês = saldo projetado já calculado
        meses.push({ label: labelsM[i], saldo: saldoProjetado, delta: saldoProjetado - saldoAtual });
        saldoAcum = saldoProjetado;
      } else {
        saldoAcum += totalProv;
        meses.push({ label: labelsM[i], saldo: saldoAcum, delta: totalProv });
      }
    }
    return meses;
  }, [saldoProjetado, saldoAtual]);

  return (
    <div className="page page-dashboard">
      <PageHeader
        title="Dashboard"
        subtitle="Visão geral do ciclo atual e dos próximos meses"
        right={<CycleProgress />}
      />

      {/* HERO METRICS */}
      <div className="hero-grid">
        <Glass className="hero-card hero-card-projetado">
          <div className="hero-label">
            <Icon name="trending_up" size={16} />
            <span>SALDO PROJETADO · FIM DO CICLO</span>
          </div>
          <div className="hero-value">{brl(saldoProjetado)}</div>
          <div className="hero-foot">
            <span className={saldoProjetado - saldoAtual >= 0 ? "delta-pos" : "delta-neg"}>
              <Icon name={saldoProjetado - saldoAtual >= 0 ? "arrow_upward" : "arrow_downward"} size={14} />
              {brl(Math.abs(saldoProjetado - saldoAtual))}
            </span>
            <span className="t-xs t-muted">depois das {provisoesRestantes.length} provisões pendentes</span>
          </div>
        </Glass>

        <Glass className="hero-card">
          <div className="hero-label"><Icon name="payments" size={16} /><span>RECEITAS DO CICLO</span></div>
          <div className="hero-value-sm">{brl(receitas)}</div>
          <div className="hero-bar">
            <div className="hero-bar-fill" style={{ background: "#22C55E", width: "100%" }} />
          </div>
          <div className="t-xs t-muted">
            +{brl(receitaRestante)} ainda esperado
          </div>
        </Glass>

        <Glass className="hero-card">
          <div className="hero-label"><Icon name="shopping_bag" size={16} /><span>GASTOS DO CICLO</span></div>
          <div className="hero-value-sm" style={{ color: "#F472B6" }}>{brl(gastos)}</div>
          <div className="hero-bar">
            <div className="hero-bar-fill" style={{ background: "#EC4899", width: Math.min(100, (gastos / receitas) * 100) + "%" }} />
          </div>
          <div className="t-xs t-muted">
            +{brl(compromissoRestante)} já comprometidos
          </div>
        </Glass>
      </div>

      {pendentes > 0 && (
        <button className="alert-banner" onClick={() => onNav("transacoes")}>
          <div className="alert-icon" style={{ background: "#F59E0B20", color: "#F59E0B" }}>
            <Icon name="inbox" size={20} />
          </div>
          <div style={{ flex: 1 }}>
            <div className="t-md">{pendentes} transações aguardando categorização</div>
            <div className="t-xs t-muted">Revisar uma a uma para manter o dashboard preciso</div>
          </div>
          <span className="btn-ghost">Revisar <Icon name="arrow_forward" size={16} /></span>
        </button>
      )}

      {/* PROJEÇÃO 6 MESES */}
      <Glass className="proj-card">
        <SectionHeader
          title="Próximos 6 meses"
          hint="Saldo projetado considerando provisões mensais e parcelas ativas"
          right={
            <button className="btn-ghost" onClick={() => onNav("provisoes")}>
              Gerenciar provisões <Icon name="arrow_forward" size={14} />
            </button>
          }
        />
        <ProjectionChart meses={projecao} />
      </Glass>

      <div className="grid-2">
        {/* GASTOS POR CATEGORIA */}
        <Glass>
          <SectionHeader
            title="Gastos por categoria"
            hint="Ciclo atual"
            right={<button className="btn-ghost"><Icon name="more_horiz" size={16} /></button>}
          />
          <CategoryDonut data={gastosPorCat} total={gastos} />
          <div className="cat-list">
            {gastosPorCat
              .map(c => {
                const limite = ORCAMENTOS[c.id];
                const pctOrc = limite ? (c.valor / limite) * 100 : null;
                const pctTot = (c.valor / gastos) * 100;
                // criticality score: budget % first, then share of total
                const score = pctOrc !== null ? pctOrc + 1000 : pctTot;
                return { ...c, limite, pctOrc, pctTot, score };
              })
              .sort((a, b) => b.score - a.score)
              .slice(0, 6)
              .map(c => {
                const overOrAt = c.pctOrc !== null && c.pctOrc >= 85;
                return (
                  <div key={c.id} className="cat-row">
                    <div className="cat-row-head">
                      <span className="cat-dot" style={{ background: c.color }} />
                      <span className="cat-name">{c.label}</span>
                      <span className="cat-pct" style={{
                        color: c.pctOrc !== null
                          ? (c.pctOrc >= 100 ? "#EF4444" : c.pctOrc >= 85 ? "#F59E0B" : "var(--text)")
                          : "var(--text)",
                      }}>
                        {c.pctOrc !== null ? Math.round(c.pctOrc) + "%" : Math.round(c.pctTot) + "%"}
                      </span>
                    </div>
                    <div className="cat-row-bar">
                      <div
                        className="cat-row-fill"
                        style={{
                          width: Math.min(100, c.pctOrc !== null ? c.pctOrc : c.pctTot) + "%",
                          background: c.pctOrc !== null && c.pctOrc >= 100 ? "#EF4444"
                                    : c.pctOrc !== null && c.pctOrc >= 85  ? "#F59E0B"
                                    : c.color,
                        }}
                      />
                    </div>
                    <div className="cat-row-foot">
                      <span className="t-xs t-muted">{brl(-c.valor)}</span>
                      <span className="t-xs t-muted">
                        {c.limite ? `de ${brl(-c.limite)} de orçamento` : "sem orçamento"}
                      </span>
                    </div>
                  </div>
                );
              })}
          </div>
        </Glass>

        {/* TOP GASTOS + ALERTAS + METAS (right column) */}
        <div className="col-stack">
          {alertas.length > 0 && (
            <Glass>
              <SectionHeader title="Alertas" hint={`${alertas.length} ${alertas.length === 1 ? "categoria" : "categorias"} próximas do limite`} />
              <div className="alert-list">
                {alertas.map(a => {
                  const c = CATEGORIAS[a.cat];
                  return (
                    <div key={a.cat} className="alert-row">
                      <div className="alert-row-icon" style={{ background: c.color + "20", color: c.color }}>
                        <Icon name={c.icon} size={18} />
                      </div>
                      <div style={{ flex: 1 }}>
                        <div className="t-sm">{c.label}</div>
                        <div className="t-xs t-muted">{brl(-a.usado)} de {brl(-a.limite)}</div>
                      </div>
                      <div className={"alert-pct " + (a.pct >= 1 ? "alert-pct-over" : "")}>
                        {Math.round(a.pct * 100)}%
                      </div>
                    </div>
                  );
                })}
              </div>
            </Glass>
          )}

          <Glass>
            <SectionHeader title="Top gastos do ciclo" />
            <div className="top-list">
              {topGastos.map(t => (
                <div key={t.id} className="top-row">
                  <div className="top-row-icon" style={{ background: CATEGORIAS[t.categoria].color + "20", color: CATEGORIAS[t.categoria].color }}>
                    <Icon name={CATEGORIAS[t.categoria].icon} size={18} />
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div className="t-sm" style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{t.desc}</div>
                    <div className="t-xs t-muted">{fmtData(t.data)} · {CATEGORIAS[t.categoria].label}</div>
                  </div>
                  <div className="t-sm" style={{ color: "#F472B6", fontVariantNumeric: "tabular-nums" }}>{brl(t.valor)}</div>
                </div>
              ))}
            </div>
          </Glass>

          <Glass>
            <SectionHeader title="Metas & cofrinhos" right={<button className="btn-ghost" onClick={() => onNav("metas")}>Ver todas</button>} />
            <div className="metas-list">
              {METAS.map(m => {
                const pct = (m.atual / m.alvo) * 100;
                return (
                  <div key={m.id} className="meta-row">
                    <div className="meta-icon" style={{ background: m.cor + "20", color: m.cor }}>
                      <Icon name={m.icon} size={18} />
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div className="meta-head">
                        <span className="t-sm">{m.nome}</span>
                        <span className="t-xs t-muted">{Math.round(pct)}%</span>
                      </div>
                      <div className="meta-bar">
                        <div className="meta-fill" style={{ width: pct + "%", background: m.cor }} />
                      </div>
                      <div className="t-xs t-muted">{brlCompact(m.atual)} de {brlCompact(m.alvo)}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </Glass>
        </div>
      </div>
    </div>
  );
}

// ---------- Projection chart (custom SVG area) ----------
function ProjectionChart({ meses }) {
  const W = 1000, H = 220, PAD_L = 60, PAD_R = 20, PAD_T = 20, PAD_B = 36;
  const innerW = W - PAD_L - PAD_R, innerH = H - PAD_T - PAD_B;
  const max = Math.max(...meses.map(m => m.saldo)) * 1.1;
  const min = Math.min(0, ...meses.map(m => m.saldo)) * 1.1;
  const range = max - min || 1;
  const x = i => PAD_L + (i / (meses.length - 1)) * innerW;
  const y = v => PAD_T + (1 - (v - min) / range) * innerH;

  const linePath = meses.map((m, i) => `${i === 0 ? "M" : "L"} ${x(i)} ${y(m.saldo)}`).join(" ");
  const areaPath = `${linePath} L ${x(meses.length - 1)} ${y(0)} L ${x(0)} ${y(0)} Z`;

  const ticks = 4;
  const tickVals = Array.from({ length: ticks + 1 }, (_, i) => min + (range / ticks) * i);

  return (
    <div className="proj-chart-wrap">
      <svg viewBox={`0 0 ${W} ${H}`} className="proj-chart" preserveAspectRatio="none">
        <defs>
          <linearGradient id="projGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%"   stopColor="#820AD1" stopOpacity="0.45" />
            <stop offset="100%" stopColor="#820AD1" stopOpacity="0.02" />
          </linearGradient>
        </defs>
        {/* grid */}
        {tickVals.map((v, i) => (
          <g key={i}>
            <line x1={PAD_L} x2={W - PAD_R} y1={y(v)} y2={y(v)} stroke="rgba(255,255,255,0.05)" />
            <text x={PAD_L - 8} y={y(v) + 4} fontSize="10" fill="rgba(255,255,255,0.4)" textAnchor="end" fontFamily="ui-monospace, monospace">
              {brlCompact(v)}
            </text>
          </g>
        ))}
        {/* zero line */}
        <line x1={PAD_L} x2={W - PAD_R} y1={y(0)} y2={y(0)} stroke="rgba(255,255,255,0.15)" strokeDasharray="3,3" />
        {/* area + line */}
        <path d={areaPath} fill="url(#projGrad)" />
        <path d={linePath} fill="none" stroke="#C084FC" strokeWidth="2" />
        {/* points */}
        {meses.map((m, i) => (
          <g key={i}>
            <circle cx={x(i)} cy={y(m.saldo)} r={i === 0 ? 5 : 4} fill={i === 0 ? "#fff" : "#C084FC"} stroke="#820AD1" strokeWidth="2" />
            <text x={x(i)} y={y(m.saldo) - 12} fontSize="11" fill="#fff" textAnchor="middle" fontWeight="600" fontFamily="ui-monospace, monospace">
              {brlCompact(m.saldo)}
            </text>
            <text x={x(i)} y={H - 14} fontSize="11" fill="rgba(255,255,255,0.55)" textAnchor="middle" fontFamily="ui-monospace, monospace">
              {m.label}
            </text>
          </g>
        ))}
        {/* "hoje" marker on first point */}
        <g>
          <line x1={x(0)} x2={x(0)} y1={PAD_T} y2={H - PAD_B} stroke="rgba(192,132,252,0.3)" strokeDasharray="2,3" />
          <text x={x(0)} y={PAD_T - 6} fontSize="10" fill="#C084FC" textAnchor="middle">FIM CICLO</text>
        </g>
      </svg>
    </div>
  );
}

// ---------- Donut ----------
function CategoryDonut({ data, total }) {
  const R = 70, r = 52, cx = 90, cy = 90;
  let acc = 0;
  const slices = data.map(d => {
    const start = acc / total;
    acc += d.valor;
    const end = acc / total;
    const a1 = start * Math.PI * 2 - Math.PI / 2;
    const a2 = end * Math.PI * 2 - Math.PI / 2;
    const large = end - start > 0.5 ? 1 : 0;
    const x1 = cx + R * Math.cos(a1), y1 = cy + R * Math.sin(a1);
    const x2 = cx + R * Math.cos(a2), y2 = cy + R * Math.sin(a2);
    const x3 = cx + r * Math.cos(a2), y3 = cy + r * Math.sin(a2);
    const x4 = cx + r * Math.cos(a1), y4 = cy + r * Math.sin(a1);
    return {
      d: `M ${x1} ${y1} A ${R} ${R} 0 ${large} 1 ${x2} ${y2} L ${x3} ${y3} A ${r} ${r} 0 ${large} 0 ${x4} ${y4} Z`,
      color: d.color,
    };
  });

  return (
    <div className="donut-wrap">
      <svg viewBox="0 0 180 180" className="donut">
        {slices.map((s, i) => <path key={i} d={s.d} fill={s.color} />)}
        <circle cx={cx} cy={cy} r={r - 1} fill="rgba(20,15,35,0.6)" />
      </svg>
      <div className="donut-center">
        <div className="t-xs t-muted">TOTAL CICLO</div>
        <div className="donut-total">{brl(-total)}</div>
      </div>
    </div>
  );
}

Object.assign(window, { Dashboard });
