// Shared UI primitives — glass cards, sidebar, header, helpers
const { useState, useEffect, useRef, useMemo } = React;

// ---------- Icon ----------
function Icon({ name, size = 20, className = "", style = {} }) {
  return (
    <span
      className={"material-symbols-outlined " + className}
      style={{ fontSize: size, lineHeight: 1, ...style }}
    >
      {name}
    </span>
  );
}

// ---------- Glass card ----------
function Glass({ children, className = "", style = {}, padded = true, hover = false, onClick }) {
  return (
    <div
      onClick={onClick}
      className={"glass " + (padded ? "p-5 " : "") + (hover ? "glass-hover " : "") + (onClick ? "cursor-pointer " : "") + className}
      style={style}
    >
      {children}
    </div>
  );
}

// ---------- Sidebar ----------
const NAV_ITEMS = [
  { id: "dashboard", label: "Dashboard",     icon: "dashboard" },
  { id: "importar",  label: "Importar",      icon: "upload_file" },
  { id: "transacoes",label: "Transações",    icon: "receipt_long", badge: "pending" },
  { id: "cartao",    label: "Cartão",        icon: "credit_card" },
  { id: "provisoes", label: "Provisões",     icon: "event_repeat" },
  { id: "metas",     label: "Metas",         icon: "flag" },
  { id: "regras",    label: "Regras",        icon: "rule" },
  { id: "config",    label: "Configurações", icon: "settings" },
];

function Sidebar({ active, onNav, pendentes }) {
  return (
    <aside className="sidebar">
      <div className="brand">
        <div className="brand-mark">
          <Icon name="account_balance_wallet" size={20} />
        </div>
        <div>
          <div className="brand-name">Fabio</div>
          <div className="brand-sub">Financeiro</div>
        </div>
      </div>

      <nav className="nav">
        {NAV_ITEMS.map(item => (
          <button
            key={item.id}
            onClick={() => onNav(item.id)}
            className={"nav-item " + (active === item.id ? "nav-item-active" : "")}
          >
            <Icon name={item.icon} size={20} />
            <span>{item.label}</span>
            {item.badge === "pending" && pendentes > 0 && (
              <span className="nav-badge">{pendentes}</span>
            )}
          </button>
        ))}
      </nav>

      <div className="sidebar-foot">
        <div className="local-chip">
          <div className="local-dot" />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="t-xs t-muted">DADOS LOCAIS</div>
            <div className="t-xs">Última importação · há 2h</div>
          </div>
          <Icon name="lock" size={14} className="t-muted-2" />
        </div>
      </div>
    </aside>
  );
}

// ---------- Cycle progress (dia X de Y) ----------
function CycleProgress({ compact = false }) {
  const total = Math.round((CICLO_FIM - CICLO_INICIO) / (1000 * 60 * 60 * 24)) + 1;
  const passados = Math.round((HOJE - CICLO_INICIO) / (1000 * 60 * 60 * 24)) + 1;
  const pct = (passados / total) * 100;

  return (
    <div className={"cycle " + (compact ? "cycle-compact" : "")}>
      <div className="cycle-meta">
        <span className="t-xs t-muted">CICLO ATUAL</span>
        <span className="t-xs">27 abr → 26 mai</span>
      </div>
      <div className="cycle-bar">
        <div className="cycle-fill" style={{ width: pct + "%" }} />
        <div className="cycle-marker" style={{ left: pct + "%" }} />
      </div>
      <div className="cycle-meta">
        <span className="t-xs t-muted">Dia {passados} de {total}</span>
        <span className="t-xs t-muted">{total - passados} dias restantes</span>
      </div>
    </div>
  );
}

// ---------- Pessoa avatar ----------
function PessoaAvatar({ id, size = 22 }) {
  const p = PESSOAS.find(x => x.id === id);
  if (!p) return null;
  return (
    <div
      className="pessoa-avatar"
      style={{
        width: size, height: size, fontSize: size * 0.45,
        background: p.cor + "30", color: p.cor, border: `1px solid ${p.cor}50`,
      }}
      title={p.nome}
    >
      {p.iniciais}
    </div>
  );
}

// ---------- Categoria chip ----------
function CategoriaChip({ id, size = "sm" }) {
  if (!id) {
    return (
      <span className="cat-chip cat-chip-empty">
        <Icon name="help" size={14} />
        <span>Sem categoria</span>
      </span>
    );
  }
  const c = CATEGORIAS[id];
  return (
    <span
      className="cat-chip"
      style={{ background: c.color + "1f", color: c.color, border: `1px solid ${c.color}40` }}
    >
      <Icon name={c.icon} size={14} />
      <span>{c.label}</span>
    </span>
  );
}

// ---------- Header (page header) ----------
function PageHeader({ title, subtitle, right }) {
  return (
    <div className="page-header">
      <div>
        <h1 className="page-title">{title}</h1>
        {subtitle && <div className="page-sub">{subtitle}</div>}
      </div>
      {right && <div className="page-header-right">{right}</div>}
    </div>
  );
}

// ---------- Section header ----------
function SectionHeader({ title, hint, right }) {
  return (
    <div className="section-header">
      <div>
        <div className="section-title">{title}</div>
        {hint && <div className="t-xs t-muted">{hint}</div>}
      </div>
      {right}
    </div>
  );
}

Object.assign(window, {
  Icon, Glass, Sidebar, CycleProgress, PessoaAvatar, CategoriaChip,
  PageHeader, SectionHeader, NAV_ITEMS,
});
