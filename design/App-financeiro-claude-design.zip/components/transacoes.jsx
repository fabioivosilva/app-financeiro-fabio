// Transações — list view + inbox de pendentes
const { useState: useStateT, useMemo: useMemoT } = React;

function Transacoes({ pendentesIds, onCategorize }) {
  const [tab, setTab] = useStateT("todas"); // todas | pendentes | inbox
  const [filtroCat, setFiltroCat] = useStateT(null);
  const [filtroPessoa, setFiltroPessoa] = useStateT(null);
  const [filtroValor, setFiltroValor] = useStateT(null); // null | "entradas" | "saidas" | "grandes"
  const [filtroData, setFiltroData] = useStateT(null); // null | "hoje" | "7d" | "ciclo"
  const [filtroStatus, setFiltroStatus] = useStateT(null); // null | "categorizada" | "pendente" | "vinculada"
  const [ordem, setOrdem] = useStateT("data-desc"); // data-desc | data-asc | valor-desc | valor-asc
  const [busca, setBusca] = useStateT("");
  const [expandido, setExpandido] = useStateT(null);

  const pendentes = TRANSACOES.filter(t => t.status === "pendente");

  const lista = useMemoT(() => {
    let arr = TRANSACOES;
    if (tab === "pendentes") arr = pendentes;
    if (filtroCat) arr = arr.filter(t => t.categoria === filtroCat);
    if (filtroPessoa) arr = arr.filter(t => t.pessoa === filtroPessoa);
    if (filtroValor === "entradas") arr = arr.filter(t => t.valor > 0);
    if (filtroValor === "saidas") arr = arr.filter(t => t.valor < 0);
    if (filtroValor === "grandes") arr = arr.filter(t => Math.abs(t.valor) >= 200);
    if (filtroData === "hoje") arr = arr.filter(t => t.data === HOJE.toISOString().slice(0, 10));
    if (filtroData === "7d") {
      const corte = new Date(HOJE); corte.setDate(corte.getDate() - 7);
      arr = arr.filter(t => new Date(t.data) >= corte);
    }
    if (filtroStatus === "categorizada") arr = arr.filter(t => t.categoria && t.status !== "pendente");
    if (filtroStatus === "pendente") arr = arr.filter(t => t.status === "pendente");
    if (filtroStatus === "vinculada") arr = arr.filter(t => t.provisao);
    if (busca) arr = arr.filter(t => t.desc.toLowerCase().includes(busca.toLowerCase()));
    const sorted = [...arr];
    if (ordem === "data-desc") sorted.sort((a, b) => b.data.localeCompare(a.data));
    if (ordem === "data-asc") sorted.sort((a, b) => a.data.localeCompare(b.data));
    if (ordem === "valor-desc") sorted.sort((a, b) => Math.abs(b.valor) - Math.abs(a.valor));
    if (ordem === "valor-asc") sorted.sort((a, b) => Math.abs(a.valor) - Math.abs(b.valor));
    return sorted;
  }, [tab, filtroCat, filtroPessoa, filtroValor, filtroData, filtroStatus, ordem, busca]);

  // group by date (only when sorting by date)
  const grupos = useMemoT(() => {
    if (!ordem.startsWith("data")) return [["__flat", lista]];
    const g = {};
    lista.forEach(t => { (g[t.data] = g[t.data] || []).push(t); });
    return Object.entries(g).sort((a, b) => ordem === "data-desc" ? b[0].localeCompare(a[0]) : a[0].localeCompare(b[0]));
  }, [lista, ordem]);

  const filtrosAtivos = [filtroCat, filtroPessoa, filtroValor, filtroData, filtroStatus].filter(Boolean).length;

  if (tab === "inbox") {
    return <Inbox onClose={() => setTab("todas")} />;
  }

  return (
    <div className="page page-transacoes">
      <PageHeader
        title="Transações"
        subtitle={`${TRANSACOES.length} transações no ciclo atual`}
        right={
          pendentes.length > 0 && (
            <button className="btn-primary" onClick={() => setTab("inbox")}>
              <Icon name="inbox" size={16} />
              Revisar {pendentes.length} pendentes
            </button>
          )
        }
      />

      <Glass padded={false} className="filters-bar">
        <div className="filters-row">
          <div className="search-wrap">
            <Icon name="search" size={18} className="t-muted" />
            <input
              placeholder="Buscar por descrição..."
              value={busca}
              onChange={e => setBusca(e.target.value)}
            />
          </div>
          <div className="tab-group">
            <button className={"tab " + (tab === "todas" ? "tab-active" : "")} onClick={() => setTab("todas")}>
              Todas <span className="tab-count">{TRANSACOES.length}</span>
            </button>
            <button className={"tab " + (tab === "pendentes" ? "tab-active" : "")} onClick={() => setTab("pendentes")}>
              Pendentes <span className="tab-count tab-count-warn">{pendentes.length}</span>
            </button>
          </div>
        </div>

        <div className="filters-row">
          <div className="filter-group">
            <FilterDropdown
              icon="sort"
              label="Ordenar"
              value={ordem}
              options={[
                { v: "data-desc", l: "Data ↓ (recente primeiro)" },
                { v: "data-asc", l: "Data ↑ (antiga primeiro)" },
                { v: "valor-desc", l: "Valor ↓ (maior primeiro)" },
                { v: "valor-asc", l: "Valor ↑ (menor primeiro)" },
              ]}
              onChange={setOrdem}
              dismissable={false}
            />
            <FilterDropdown
              icon="payments"
              label="Valor"
              value={filtroValor}
              options={[
                { v: "entradas", l: "Apenas entradas" },
                { v: "saidas", l: "Apenas saídas" },
                { v: "grandes", l: "Acima de R$ 200" },
              ]}
              onChange={setFiltroValor}
            />
            <FilterDropdown
              icon="event"
              label="Data"
              value={filtroData}
              options={[
                { v: "hoje", l: "Hoje" },
                { v: "7d", l: "Últimos 7 dias" },
                { v: "ciclo", l: "Ciclo atual" },
              ]}
              onChange={setFiltroData}
            />
            <FilterDropdown
              icon="flag"
              label="Status"
              value={filtroStatus}
              options={[
                { v: "categorizada", l: "Categorizada" },
                { v: "pendente", l: "Pendente" },
                { v: "vinculada", l: "Vinculada à provisão" },
              ]}
              onChange={setFiltroStatus}
            />
            <button
              className={"chip-filter " + (filtroCat ? "chip-filter-on" : "")}
              onClick={() => setFiltroCat(null)}
            >
              <Icon name="category" size={14} />
              {filtroCat ? CATEGORIAS[filtroCat].label : "Categoria"}
              {filtroCat && <Icon name="close" size={14} />}
            </button>
            <button
              className={"chip-filter " + (filtroPessoa ? "chip-filter-on" : "")}
              onClick={() => setFiltroPessoa(null)}
            >
              <Icon name="person" size={14} />
              {filtroPessoa ? PESSOAS.find(p => p.id === filtroPessoa).nome : "Pessoa"}
              {filtroPessoa && <Icon name="close" size={14} />}
            </button>
            {filtrosAtivos > 0 && (
              <button
                className="chip-clear"
                onClick={() => {
                  setFiltroCat(null); setFiltroPessoa(null); setFiltroValor(null);
                  setFiltroData(null); setFiltroStatus(null);
                }}
              >
                <Icon name="filter_alt_off" size={14} /> Limpar {filtrosAtivos}
              </button>
            )}
          </div>
        </div>
      </Glass>

      <Glass padded={false}>
        {grupos.length === 0 || (grupos.length === 1 && grupos[0][1].length === 0) ? (
          <div className="empty-state-mini">
            <Icon name="search_off" size={32} className="t-muted" />
            <div className="t-sm">Nenhuma transação encontrada</div>
          </div>
        ) : (
          grupos.map(([data, items]) => {
            const total = items.reduce((s, t) => s + t.valor, 0);
            return (
              <div key={data} className="day-group">
                {data !== "__flat" && (
                  <div className="day-header">
                    <div className="day-label">
                      <span className="t-sm">{fmtData(data)}</span>
                      <span className="t-xs t-muted">· {diaSemana(data)}</span>
                    </div>
                    <div className="t-xs t-muted" style={{ fontVariantNumeric: "tabular-nums" }}>
                      {brl(total)}
                    </div>
                  </div>
                )}
                {items.map(t => (
                  <TransactionRow
                    key={t.id}
                    t={t}
                    expanded={expandido === t.id}
                    onToggle={() => setExpandido(expandido === t.id ? null : t.id)}
                  />
                ))}
              </div>
            );
          })
        )}
      </Glass>
    </div>
  );
}

// ---------- Filter dropdown ----------
function FilterDropdown({ icon, label, value, options, onChange, dismissable = true }) {
  const [open, setOpen] = useStateT(false);
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (!open) return;
    const onDoc = e => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, [open]);
  const selected = options.find(o => o.v === value);
  return (
    <div className="filter-dd" ref={ref}>
      <button
        className={"chip-filter " + (value ? "chip-filter-on" : "")}
        onClick={(e) => {
          if (dismissable && value && e.target.closest(".chip-x")) {
            onChange(null);
            return;
          }
          setOpen(!open);
        }}
      >
        <Icon name={icon} size={14} />
        <span>{selected ? selected.l : label}</span>
        {dismissable && value
          ? <span className="chip-x"><Icon name="close" size={14} /></span>
          : <Icon name="expand_more" size={14} />}
      </button>
      {open && (
        <div className="filter-dd-menu">
          {options.map(o => (
            <button
              key={o.v}
              className={"filter-dd-opt " + (o.v === value ? "filter-dd-opt-on" : "")}
              onClick={() => { onChange(o.v); setOpen(false); }}
            >
              {o.v === value && <Icon name="check" size={14} />}
              <span style={{ marginLeft: o.v === value ? 0 : 22 }}>{o.l}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

      <Glass padded={false}>
        {grupos.length === 0 ? (
          <div className="empty-state-mini">
            <Icon name="search_off" size={32} className="t-muted" />
            <div className="t-sm">Nenhuma transação encontrada</div>
          </div>
        ) : (
          grupos.map(([data, items]) => {
            const total = items.reduce((s, t) => s + t.valor, 0);
            return (
              <div key={data} className="day-group">
                <div className="day-header">
                  <div className="day-label">
                    <span className="t-sm">{fmtData(data)}</span>
                    <span className="t-xs t-muted">· {diaSemana(data)}</span>
                  </div>
                  <div className="t-xs t-muted" style={{ fontVariantNumeric: "tabular-nums" }}>
                    {brl(total)}
                  </div>
                </div>
                {items.map(t => (
                  <TransactionRow
                    key={t.id}
                    t={t}
                    expanded={expandido === t.id}
                    onToggle={() => setExpandido(expandido === t.id ? null : t.id)}
                  />
                ))}
              </div>
            );
          })
        )}
      </Glass>
    </div>
  );
}

function TransactionRow({ t, expanded, onToggle }) {
  const cat = t.categoria ? CATEGORIAS[t.categoria] : null;
  return (
    <>
      <div className={"tx-row " + (t.status === "pendente" ? "tx-row-pending " : "") + (expanded ? "tx-row-expanded" : "")} onClick={onToggle}>
        <div className="tx-icon" style={{ background: cat ? cat.color + "20" : "#F59E0B20", color: cat ? cat.color : "#F59E0B" }}>
          <Icon name={cat ? cat.icon : "help"} size={18} />
        </div>
        <div className="tx-main">
          <div className="tx-desc">{t.desc}</div>
          <div className="tx-meta">
            <CategoriaChip id={t.categoria} />
            {t.pessoa && <PessoaAvatar id={t.pessoa} size={18} />}
            <span className="t-xs t-muted">· {t.fonte}</span>
            {t.provisao && <span className="tx-prov-link"><Icon name="link" size={12} /> Provisão</span>}
          </div>
        </div>
        <div className={"tx-val " + (t.valor > 0 ? "tx-val-pos" : "")}>
          {brl(t.valor)}
        </div>
        <Icon name={expanded ? "expand_less" : "expand_more"} size={20} className="t-muted" />
      </div>
      {expanded && (
        <div className="tx-detail">
          <div className="tx-detail-grid">
            <div>
              <div className="t-xs t-muted">FONTE</div>
              <div className="t-sm">{t.fonte}</div>
            </div>
            <div>
              <div className="t-xs t-muted">DATA</div>
              <div className="t-sm">{fmtData(t.data)} ({diaSemana(t.data)})</div>
            </div>
            <div>
              <div className="t-xs t-muted">VALOR</div>
              <div className="t-sm" style={{ fontVariantNumeric: "tabular-nums" }}>{brl(t.valor)}</div>
            </div>
            <div>
              <div className="t-xs t-muted">PESSOA</div>
              <div className="t-sm">{t.pessoa ? PESSOAS.find(p => p.id === t.pessoa).nome : "—"}</div>
            </div>
          </div>
          <div className="tx-actions">
            <button className="btn-ghost"><Icon name="edit" size={14} />Editar categoria</button>
            <button className="btn-ghost"><Icon name="rule" size={14} />Criar regra</button>
            <button className="btn-ghost"><Icon name="call_split" size={14} />Dividir</button>
            <button className="btn-ghost"><Icon name="link" size={14} />Vincular provisão</button>
          </div>
        </div>
      )}
    </>
  );
}

// ---------- Inbox de pendentes (one-by-one) ----------
function Inbox({ onClose }) {
  const pendentes = TRANSACOES.filter(t => t.status === "pendente");
  const [idx, setIdx] = useStateT(0);
  const [done, setDone] = useStateT([]);

  if (idx >= pendentes.length || done.length === pendentes.length) {
    return (
      <div className="page page-inbox-done">
        <Glass className="inbox-done">
          <div className="inbox-done-icon">
            <Icon name="task_alt" size={48} />
          </div>
          <div className="inbox-done-title">Tudo categorizado!</div>
          <div className="inbox-done-sub">{pendentes.length} transações revisadas. Seu dashboard está atualizado.</div>
          <button className="btn-primary" onClick={onClose}>Voltar para transações</button>
        </Glass>
      </div>
    );
  }

  const t = pendentes[idx];
  // fake suggestion
  const sugestao = t.valor > 0 ? "transferencia" : ["mercado", "restaurante", "transporte", "lazer", "outros"][idx % 5];

  const next = () => {
    setDone([...done, t.id]);
    setIdx(idx + 1);
  };

  return (
    <div className="page page-inbox">
      <div className="inbox-head">
        <button className="btn-ghost" onClick={onClose}>
          <Icon name="arrow_back" size={16} /> Sair
        </button>
        <div className="inbox-progress">
          <div className="t-xs t-muted">REVISANDO</div>
          <div className="inbox-counter">{idx + 1} <span className="t-muted">/ {pendentes.length}</span></div>
        </div>
        <div className="inbox-bar">
          <div className="inbox-bar-fill" style={{ width: ((idx) / pendentes.length) * 100 + "%" }} />
        </div>
      </div>

      <Glass className="inbox-card">
        <div className="inbox-source">
          <Icon name="upload_file" size={14} /> {t.fonte} · {fmtData(t.data)}
        </div>
        <div className="inbox-desc">{t.desc}</div>
        <div className={"inbox-val " + (t.valor > 0 ? "tx-val-pos" : "")}>
          {brl(t.valor)}
        </div>

        <div className="inbox-suggest">
          <div className="t-xs t-muted">SUGESTÃO DO APP</div>
          <div className="inbox-suggest-row">
            <CategoriaChip id={sugestao} />
            <span className="t-xs t-muted">baseado em descrições parecidas</span>
          </div>
        </div>

        <div className="inbox-grid-label">OU ESCOLHA UMA CATEGORIA</div>
        <div className="inbox-cat-grid">
          {Object.entries(CATEGORIAS).filter(([k]) => k !== "transferencia" || t.valor > 0).map(([k, c]) => (
            <button key={k} className={"inbox-cat " + (k === sugestao ? "inbox-cat-suggest" : "")}>
              <Icon name={c.icon} size={18} style={{ color: c.color }} />
              <span>{c.label}</span>
            </button>
          ))}
        </div>

        <div className="inbox-people">
          <div className="t-xs t-muted">VINCULAR A</div>
          <div className="inbox-people-row">
            {PESSOAS.map(p => (
              <button key={p.id} className="inbox-person">
                <div className="pessoa-avatar" style={{ background: p.cor + "30", color: p.cor, border: `1px solid ${p.cor}50`, width: 22, height: 22, fontSize: 11 }}>
                  {p.iniciais}
                </div>
                {p.nome}
              </button>
            ))}
          </div>
        </div>

        <div className="inbox-foot">
          <label className="inbox-rule">
            <input type="checkbox" defaultChecked />
            <span>Criar regra automática para "{t.desc.split(" ")[0]}"</span>
          </label>
          <div className="inbox-actions">
            <button className="btn-ghost" onClick={next}>
              <Icon name="skip_next" size={16} /> Pular
            </button>
            <button className="btn-primary" onClick={next}>
              Categorizar e próxima <Icon name="arrow_forward" size={16} />
            </button>
          </div>
        </div>
      </Glass>
    </div>
  );
}

Object.assign(window, { Transacoes });
