// Mock data for App Financeiro Fabio
// Cycle: 27 → 26 of next month. Today = day 12 of cycle (May 8, 2026)

const HOJE = new Date(2026, 4, 8); // May 8, 2026
const CICLO_INICIO = new Date(2026, 3, 27); // Apr 27
const CICLO_FIM = new Date(2026, 4, 26);    // May 26

const CATEGORIAS = {
  mercado:      { label: "Mercado",       color: "#A855F7", icon: "shopping_cart" },
  restaurante:  { label: "Restaurante",   color: "#EC4899", icon: "restaurant" },
  transporte:   { label: "Transporte",    color: "#06B6D4", icon: "directions_car" },
  assinatura:   { label: "Assinaturas",   color: "#F59E0B", icon: "subscriptions" },
  saude:        { label: "Saúde",         color: "#10B981", icon: "health_and_safety" },
  casa:         { label: "Casa",          color: "#6366F1", icon: "home" },
  lazer:        { label: "Lazer",         color: "#F43F5E", icon: "sports_esports" },
  educacao:     { label: "Educação",      color: "#8B5CF6", icon: "school" },
  salario:      { label: "Salário",       color: "#22C55E", icon: "payments" },
  freelance:    { label: "Freelance",     color: "#14B8A6", icon: "work" },
  transferencia:{ label: "Transferência", color: "#94A3B8", icon: "swap_horiz" },
  outros:       { label: "Outros",        color: "#64748B", icon: "category" },
};

const PESSOAS = [
  { id: "fabio",   nome: "Fabio",   cor: "#820AD1", iniciais: "F" },
  { id: "thiago",  nome: "Thiago",  cor: "#06B6D4", iniciais: "T" },
  { id: "shared",  nome: "Compartilhado", cor: "#A855F7", iniciais: "C" },
];

// Transactions in current cycle (Apr 27 → May 26). Today is May 8.
const TRANSACOES = [
  // Receitas
  { id: "t1",  data: "2026-04-27", desc: "Salário Empresa XYZ",      valor:  8500.00, categoria: "salario",      pessoa: "fabio",  fonte: "OFX Itaú",        status: "ok" },
  { id: "t2",  data: "2026-05-05", desc: "Freelance Cliente A",      valor:  2200.00, categoria: "freelance",    pessoa: "fabio",  fonte: "OFX Itaú",        status: "ok" },

  // Mercado
  { id: "t3",  data: "2026-04-28", desc: "PAO DE ACUCAR 2841",       valor:  -487.32, categoria: "mercado",      pessoa: "shared", fonte: "Cartão Itaú",     status: "ok" },
  { id: "t4",  data: "2026-05-02", desc: "MERCADO EXTRA",            valor:  -312.18, categoria: "mercado",      pessoa: "shared", fonte: "Cartão Itaú",     status: "ok" },
  { id: "t5",  data: "2026-05-07", desc: "HORTIFRUTI VILA",          valor:   -89.40, categoria: "mercado",      pessoa: "shared", fonte: "OFX Itaú",        status: "ok" },

  // Restaurante
  { id: "t6",  data: "2026-04-29", desc: "IFOOD*OUTBACK",            valor:  -156.90, categoria: "restaurante",  pessoa: "shared", fonte: "Cartão Itaú",     status: "ok" },
  { id: "t7",  data: "2026-05-01", desc: "STARBUCKS PAULISTA",       valor:   -38.50, categoria: "restaurante",  pessoa: "fabio",  fonte: "Cartão Itaú",     status: "ok" },
  { id: "t8",  data: "2026-05-03", desc: "RAPPI*MCDONALDS",          valor:   -62.30, categoria: "restaurante",  pessoa: "thiago", fonte: "Cartão Itaú",     status: "ok" },
  { id: "t9",  data: "2026-05-06", desc: "PADARIA SAO ROQUE",        valor:   -24.80, categoria: "restaurante",  pessoa: "fabio",  fonte: "OFX Itaú",        status: "ok" },

  // Transporte
  { id: "t10", data: "2026-04-30", desc: "UBER *TRIP",               valor:   -28.40, categoria: "transporte",   pessoa: "fabio",  fonte: "Cartão Itaú",     status: "ok" },
  { id: "t11", data: "2026-05-04", desc: "POSTO SHELL VL MAR",       valor:  -245.00, categoria: "transporte",   pessoa: "shared", fonte: "Cartão Itaú",     status: "ok" },
  { id: "t12", data: "2026-05-07", desc: "99POP",                    valor:   -19.80, categoria: "transporte",   pessoa: "thiago", fonte: "Cartão Itaú",     status: "ok" },

  // Assinaturas
  { id: "t13", data: "2026-05-01", desc: "NETFLIX.COM",              valor:   -55.90, categoria: "assinatura",   pessoa: "shared", fonte: "Cartão Itaú",     status: "ok",     provisao: "p1" },
  { id: "t14", data: "2026-05-03", desc: "SPOTIFY FAMILY",           valor:   -34.90, categoria: "assinatura",   pessoa: "shared", fonte: "Cartão Itaú",     status: "ok",     provisao: "p2" },
  { id: "t15", data: "2026-05-05", desc: "ICLOUD+ 200GB",            valor:   -11.90, categoria: "assinatura",   pessoa: "fabio",  fonte: "Cartão Itaú",     status: "ok" },

  // Casa
  { id: "t16", data: "2026-05-02", desc: "ENEL DISTRIBUIDORA",       valor:  -284.00, categoria: "casa",         pessoa: "shared", fonte: "OFX Itaú",        status: "ok",     provisao: "p3" },
  { id: "t17", data: "2026-05-06", desc: "SABESP",                   valor:  -118.40, categoria: "casa",         pessoa: "shared", fonte: "OFX Itaú",        status: "ok" },

  // Saúde
  { id: "t18", data: "2026-05-04", desc: "DROGARIA SAO PAULO",       valor:   -78.20, categoria: "saude",        pessoa: "fabio",  fonte: "Cartão Itaú",     status: "ok" },

  // Lazer
  { id: "t19", data: "2026-05-03", desc: "INGRESSO.COM",             valor:  -180.00, categoria: "lazer",        pessoa: "shared", fonte: "Cartão Itaú",     status: "ok" },

  // Pendentes (sem categoria — auto-categorizador não bateu)
  { id: "t20", data: "2026-05-05", desc: "PG*BOUTIQUE LISBOA",       valor:  -340.00, categoria: null,           pessoa: null,     fonte: "Cartão Itaú",     status: "pendente" },
  { id: "t21", data: "2026-05-06", desc: "MP*ANA SOUZA",             valor:  -150.00, categoria: null,           pessoa: null,     fonte: "OFX Itaú",        status: "pendente" },
  { id: "t22", data: "2026-05-07", desc: "TRANSF PIX RECEBIDA",      valor:   320.00, categoria: null,           pessoa: null,     fonte: "OFX Itaú",        status: "pendente" },
  { id: "t23", data: "2026-05-07", desc: "AMAZON SERVICES",          valor:   -49.90, categoria: null,           pessoa: null,     fonte: "Cartão Itaú",     status: "pendente" },
];

// Provisões (recorrências futuras + parcelas)
const PROVISOES = [
  { id: "p1",  desc: "Netflix",                 categoria: "assinatura", valor:   -55.90, dia:  1,  tipo: "mensal",   ativa: true,  inicio: "2024-01-01" },
  { id: "p2",  desc: "Spotify Family",          categoria: "assinatura", valor:   -34.90, dia:  3,  tipo: "mensal",   ativa: true,  inicio: "2024-01-01" },
  { id: "p3",  desc: "Energia (Enel)",          categoria: "casa",       valor:  -290.00, dia:  2,  tipo: "mensal",   ativa: true,  inicio: "2024-01-01" },
  { id: "p4",  desc: "Internet (Vivo Fibra)",   categoria: "casa",       valor:  -129.90, dia: 10,  tipo: "mensal",   ativa: true,  inicio: "2024-01-01" },
  { id: "p5",  desc: "Aluguel",                 categoria: "casa",       valor: -2800.00, dia:  5,  tipo: "mensal",   ativa: true,  inicio: "2024-01-01" },
  { id: "p6",  desc: "Academia",                categoria: "saude",      valor:  -149.00, dia: 15,  tipo: "mensal",   ativa: true,  inicio: "2024-01-01" },
  { id: "p7",  desc: "Plano de Saúde",          categoria: "saude",      valor:  -680.00, dia: 20,  tipo: "mensal",   ativa: true,  inicio: "2024-01-01" },
  { id: "p8",  desc: "Salário Empresa XYZ",     categoria: "salario",    valor:  8500.00, dia: 27,  tipo: "mensal",   ativa: true,  inicio: "2024-01-01" },
  { id: "p9",  desc: "Financiamento Carro",     categoria: "transporte", valor:  -890.00, dia: 12,  tipo: "parcela",  ativa: true,  parcelas: { atual: 18, total: 36 } },
  { id: "p10", desc: "Curso Inglês (parcelado)",categoria: "educacao",   valor:  -320.00, dia:  8,  tipo: "parcela",  ativa: true,  parcelas: { atual:  4, total: 12 } },
];

const METAS = [
  { id: "m1", nome: "Reserva de Emergência",  alvo: 30000, atual: 18400, cor: "#22C55E", icon: "shield" },
  { id: "m2", nome: "Viagem Japão 2027",      alvo: 25000, atual:  6800, cor: "#EC4899", icon: "flight" },
  { id: "m3", nome: "Trocar Notebook",        alvo:  9000, atual:  2100, cor: "#06B6D4", icon: "laptop_mac" },
];

const ORCAMENTOS = {
  mercado:     1200,
  restaurante:  600,
  transporte:   500,
  lazer:        400,
  assinatura:   150,
};

// Helpers
function brl(n) {
  const sign = n < 0 ? "-" : "";
  const abs = Math.abs(n);
  return sign + "R$ " + abs.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function brlCompact(n) {
  const abs = Math.abs(n);
  if (abs >= 1000) return (n < 0 ? "-" : "") + "R$ " + (abs/1000).toFixed(abs >= 10000 ? 0 : 1) + "k";
  return brl(n);
}
function fmtData(s) {
  const [y, m, d] = s.split("-").map(Number);
  return `${String(d).padStart(2,"0")}/${String(m).padStart(2,"0")}`;
}
function diaSemana(s) {
  const [y, m, d] = s.split("-").map(Number);
  const dt = new Date(y, m-1, d);
  return ["dom","seg","ter","qua","qui","sex","sáb"][dt.getDay()];
}

Object.assign(window, {
  HOJE, CICLO_INICIO, CICLO_FIM,
  CATEGORIAS, PESSOAS, TRANSACOES, PROVISOES, METAS, ORCAMENTOS,
  brl, brlCompact, fmtData, diaSemana,
});
